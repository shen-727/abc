#include "ESPAsyncWebServer.h"

const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link
      rel="stylesheet"
      href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
      integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr"
      crossorigin="anonymous"
    />
    <style>
      html {
        font-family: Arial;
        display: inline-block;
        margin: 200px auto;
        text-align: center;
      }
      h1 {
        font-size: 3rem;
      }
      p {
        font-size: 3rem;
      }
      .units {
        font-size: 1.2rem;
      }
      .dht-labels {
        font-size: 1.5rem;
        vertical-align: middle;
        padding-bottom: 15px;
      }
    </style>
    <title>人体健康数据实时监测平台</title>
  </head>
  <body>
    <h1>人体健康数据实时监测平台</h1>

    <h2>人体心率数据</h2>
    <p>
      <i class="fa fa-heart" style="color: #059e8a"></i>
      <span class="dht-labels">HEARTRATE</span>
      <span id="heartrate">%HEARTRATE%</span>
      <sup class="units">BPM</sup>
    </p>

    <h2>人体体温数据</h2>
    <p>
      <i class="fas fa-thermometer-half" style="color: #059e8a"></i>
      <span class="dht-labels">Temperature</span>
      <span id="temperature">%TEMPERATURE%</span>
      <sup class="units">&deg;C</sup>
    </p>

    <h2>人体运动步数</h2>
    <p>
      <i class="fa fa-heart" style="color: #059e8a"></i>
      <span class="dht-labels">SPORTS</span>
      <span id="sports">%SPORTS%</span>
      <sup class="units">Step</sup>
    </p>

    <h2>人体运动距离</h2>
    <p>
      <i class="fa fa-heart" style="color: #059e8a"></i>
      <span class="dht-labels">SPORTSDISTANCE</span>
      <span id="sportsdistance">%SPORTSDISTANCE%</span>
      <sup class="units">meter</sup>
    </p>
    <hr />
    <h2>心率图</h2>
    <canvas
      id="draw"
      width="350"
      height="350"
      style="border: 1px solid #deb887"
    >
    </canvas>
  </body>

  <script type="text/javascript">
    var point_x1 = 0;
    var point_x2 = 0;
    var point_y1 = 170;
    var point_y2 = 170;
    var draw_line = document.getElementById("draw");
    var show = draw_line.getContext("2d");

    var heart_value = new EventSource("/heart_value");
    heart_value.onmessage = function (event) {
      point_x2 = point_x2 + 1;
      point_y2 = event.data-0;
      show.moveTo(point_x1, point_y1);
      show.lineTo(point_x2, point_y2);
      show.stroke();
      point_x1 = point_x2;
      point_y1 = point_y2;
      if (point_x1 > 350) {
        point_x1 = 0;
        point_x2 = 0;
        show.fillStyle = "White";
        show.fillRect(0, 0, 350, 350);
        show.beginPath();

      }
    };
  </script>

  <script>
    var temperature = new EventSource("/temperature");
    temperature.onmessage = function (event) {
      document.getElementById("temperature").innerHTML = event.data;
    };
    var heartrate = new EventSource("/heartrate");
    heartrate.onmessage = function (event) {
      document.getElementById("heartrate").innerHTML = event.data;
    };
    var sports = new EventSource("/sports");
    sports.onmessage = function (event) {
      document.getElementById("sports").innerHTML = event.data;
    };
    var sportsdistance = new EventSource("/sportsdistance");
    sportsdistance.onmessage = function (event) {
      document.getElementById("sportsdistance").innerHTML = event.data;
    };
  </script>
</html>
)rawliteral";

