//本项目必须得在同一网络下工作哦

// Import required libraries
#include "WiFi.h"
// #include "ESPAsyncWebServer.h"
#include "html.h"

// Replace with your network credentials
const char *ssid = "密码八个八";
const char *password = "mimabageba";

// Create AsyncWebServer object on port 80
AsyncWebServer server(80);

AsyncEventSource temperature("/temperature");
AsyncEventSource heartrate("/heartrate");
AsyncEventSource sports("/sports");
AsyncEventSource sportsdistance("/sportsdistance");
AsyncEventSource heart_value("/heart_value");

String data;
char choose;

void setup()
{
  // Serial2 port for debugging purposes
  Serial.begin(115200);
  Serial2.begin(115200);

  // Connect to Wi-Fi
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
    Serial.println("Connecting to WiFi..");
  }

  // Print ESP32 Local IP Address

  Serial.println("Connected\nIP Address:");
  Serial.println(WiFi.localIP());

  server.addHandler(&temperature);    // 将EventSource添加到服务器中
  server.addHandler(&heartrate);      // 将EventSource添加到服务器中
  server.addHandler(&sports);         // 将EventSource添加到服务器中
  server.addHandler(&sportsdistance); // 将EventSource添加到服务器中
  server.addHandler(&heart_value);    // 将EventSource添加到服务器中
  // Route for root / web page
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request) {
    request->send_P(200, "text/html", index_html);
  });

  // Start server
  server.begin();
  Serial.println("Server Started");
}

void loop()
{
  if (Serial2.available() > 0)
  {
    choose = (char)Serial2.read();

    while (Serial2.available() == 0)
      ;
    while (Serial2.available() > 0)
      data += (char)Serial2.read();
    switch (choose)
    {
    case 'A':
      sports.send(data.c_str());
      break;
    case 'B':
      sportsdistance.send(data.c_str());
      break;
    case 'C':
      heartrate.send(data.c_str());
      break;
    case 'D':
      temperature.send(data.c_str());
      break;
    case 'E':
      heart_value.send(data.c_str());
      break;
    default:
      break;
    }
    data.clear();
  }
}
